package com.dev.doctorfinder.user.fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dev.doctorfinder.R;
import com.dev.doctorfinder.adapter.MenuListAdapter;
import com.dev.doctorfinder.databinding.FragmentShoppingBinding;
import com.dev.doctorfinder.model.CartModel;
import com.dev.doctorfinder.user.MainActivity;

import java.util.ArrayList;

public class ShoppingFragment extends Fragment {

    FragmentShoppingBinding binding;
    MainActivity activity;
    MenuListAdapter adapter;
    ArrayList<CartModel> list = new ArrayList<>();

    public ShoppingFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (MainActivity) requireActivity();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentShoppingBinding.inflate(getLayoutInflater(), container, false);

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        activity.binding.toolbar.tvTitle.setText("Shop");
        activity.binding.toolbar.actionMenu.setImageResource(R.drawable.ic_menu);
        activity.binding.toolbar.actionMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.binding.drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        adapter = new MenuListAdapter(list);
        binding.rvProducts.setLayoutManager(new GridLayoutManager(requireContext(), 2));
        binding.rvProducts.setAdapter(adapter);

    }



}