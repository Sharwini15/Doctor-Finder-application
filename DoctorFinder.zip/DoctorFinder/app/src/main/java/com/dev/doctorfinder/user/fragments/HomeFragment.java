package com.dev.doctorfinder.user.fragments;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.dev.doctorfinder.R;
import com.dev.doctorfinder.adapter.DoctorsAdaptor;
import com.dev.doctorfinder.adapter.PagerAdapter;
import com.dev.doctorfinder.databinding.FragmentHomeBinding;
import com.dev.doctorfinder.model.DoctorsModel;
import com.dev.doctorfinder.model.PagerModel;
import com.dev.doctorfinder.user.MainActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    private FragmentHomeBinding binding;
    PagerAdapter adapter;
    DoctorsAdaptor doctorsAdaptor;
    ArrayList<PagerModel> list = new ArrayList<>();
    ArrayList<DoctorsModel> doctorsModels = new ArrayList<>();
    MainActivity activity;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference reference;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (MainActivity) requireActivity();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        activity.binding.toolbar.tvTitle.setText("Home");
        activity.binding.toolbar.actionMenu.setImageResource(R.drawable.ic_menu);

        setViewPager();

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        activity.binding.toolbar.actionMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.binding.drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        firebaseDatabase = FirebaseDatabase.getInstance("https://doctorfinder-371dd-default-rtdb.firebaseio.com");
        reference = firebaseDatabase.getReference();
        setRecycler();
    }

    public void setViewPager() {

        list.clear();
        list.add(new PagerModel(R.drawable.vp2));
        list.add(new PagerModel(R.drawable.vp4));
        list.add(new PagerModel(R.drawable.vp3));
        list.add(new PagerModel(R.drawable.vp1));
        adapter = new PagerAdapter(requireContext(), list);
        binding.viewPager.setAdapter(adapter);
        binding.indicator.setViewPager2(binding.viewPager);
    }

    public void setRecycler() {
        binding.rvDoc.setLayoutManager(new LinearLayoutManager(requireContext()));
        doctorsAdaptor = new DoctorsAdaptor(doctorsModels, this, "user");
        binding.rvDoc.setAdapter(doctorsAdaptor);


        ProgressDialog dialog = new ProgressDialog(requireContext());
        dialog.setCancelable(true);
        dialog.setMessage("Loading");
        dialog.show();
        doctorsModels.clear();

        reference.child("doctors").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dialog.dismiss();
                if (snapshot.exists()) {
                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                        DoctorsModel model = snapshot1.getValue(DoctorsModel.class);
                        doctorsModels.add(model);
                        doctorsAdaptor.notifyItemInserted(doctorsModels.size() - 1);
                    }

                } else {
                    Toast.makeText(activity, "No Data to show", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(activity, error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });

    }

}