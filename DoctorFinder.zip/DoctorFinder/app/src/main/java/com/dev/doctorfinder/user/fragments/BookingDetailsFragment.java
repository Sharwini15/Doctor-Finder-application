package com.dev.doctorfinder.user.fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.dev.doctorfinder.R;
import com.dev.doctorfinder.admin.AdminMainActivity;
import com.dev.doctorfinder.admin.fragments.AdminBookingFragment;
import com.dev.doctorfinder.databinding.FragmentAdminBookingDetailsBinding;
import com.dev.doctorfinder.databinding.FragmentBookingDetailsBinding;
import com.dev.doctorfinder.model.BookingModel;
import com.dev.doctorfinder.user.MainActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.skydoves.powermenu.OnMenuItemClickListener;
import com.skydoves.powermenu.PowerMenu;
import com.skydoves.powermenu.PowerMenuItem;

import java.util.Objects;

public class BookingDetailsFragment extends Fragment {

    FragmentBookingDetailsBinding binding;
    BookingModel model;
    String checkValue = "";
    FirebaseDatabase firebaseDatabase;
    DatabaseReference ref;
    MainActivity activity;

    public BookingDetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            if (getArguments() != null) {
                model = (BookingModel) getArguments().getSerializable("data");
                checkValue = getArguments().getString("value");
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (MainActivity) requireActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentBookingDetailsBinding.inflate(getLayoutInflater(), container, false);
        firebaseDatabase = FirebaseDatabase.getInstance("https://doctorfinder-371dd-default-rtdb.firebaseio.com");
        ref = firebaseDatabase.getReference("appointments");
        return binding.getRoot();
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        activity.binding.toolbar.tvTitle.setText("Appointment Details");
        activity.binding.toolbar.actionMenu.setImageResource(R.drawable.ic_baseline_arrow_back_ios_new_24);
        activity.binding.toolbar.actionMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                replaceBack(new BookingsFragment());
            }
        });

        if (model != null) {
            binding.tvTitle.setText(model.getTitle());
            binding.tvDetails.setText(model.getDetails());
            binding.tvEmail.setText(model.getEmail());
            binding.tvDate.setText(model.formatedTime());
            binding.tvStatus.setText(model.getStatus());
        }

        if (Objects.equals(checkValue, "user")) {
            binding.btnUpdate.setVisibility(View.GONE);
        }
        binding.tvStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Objects.equals(checkValue, "admin")) {
                    powerMenu(v);
                }
            }
        });
    }

    public void powerMenu(View view) {
        PowerMenu menu = new PowerMenu.Builder(requireContext()).build();
        menu.setTextColor(Color.BLACK);
        menu.setMenuRadius(15f);
        menu.addItem(new PowerMenuItem("Pending"));
        menu.addItem(new PowerMenuItem("Approved"));
        menu.addItem(new PowerMenuItem("Reject"));

        menu.setOnMenuItemClickListener(new OnMenuItemClickListener<PowerMenuItem>() {
            @Override
            public void onItemClick(int position, PowerMenuItem item) {
                binding.tvStatus.setText(item.title);
            }
        });

        menu.showAsAnchorLeftBottom(view);

    }

    private void replaceBack(Fragment fragment) {
        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.addToBackStack(null);
        transaction.replace(R.id.container, fragment);
        transaction.commit();
    }

}