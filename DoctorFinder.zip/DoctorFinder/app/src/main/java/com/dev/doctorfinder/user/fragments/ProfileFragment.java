package com.dev.doctorfinder.user.fragments;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.dev.doctorfinder.R;
import com.dev.doctorfinder.databinding.FragmentProfileBinding;
import com.dev.doctorfinder.model.User;
import com.dev.doctorfinder.user.MainActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileFragment extends Fragment {
    FragmentProfileBinding binding;
    MainActivity activity;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference ref;
    User user;

    public ProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (MainActivity) requireActivity();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentProfileBinding.inflate(getLayoutInflater(), container, false);
        return binding.getRoot();
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        ProgressDialog dialog = new ProgressDialog(requireContext());
        dialog.setMessage("Loading...");
        dialog.setCancelable(false);
        dialog.show();

        activity.binding.toolbar.tvTitle.setText("Profile");
        activity.binding.toolbar.actionMenu.setImageResource(R.drawable.ic_menu);
        activity.binding.toolbar.actionMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.binding.drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        firebaseDatabase = FirebaseDatabase.getInstance("https://doctorfinder-371dd-default-rtdb.firebaseio.com");
        ref = firebaseDatabase.getReference("Users");

        ref.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dialog.dismiss();
                if (snapshot.exists()) {
                    String name = (String) snapshot.child("name").getValue();
                    String phoneNumber = (String) snapshot.child("phoneNumber").getValue();
                    String email = (String) snapshot.child("email").getValue();
                    String imageUri = (String) snapshot.child("imageUri").getValue();
                    user = new User(FirebaseAuth.getInstance().getCurrentUser().getUid(), name, email, phoneNumber, imageUri);
                    binding.tvName.setText(name);
                    binding.tvPhone.setText(phoneNumber);
                    binding.tvEmail.setText(email);

                    Glide.with(requireContext()).load(imageUri).into(binding.imguser);

                } else {
                    Toast.makeText(requireContext(), "No data for user", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
                Toast.makeText(requireContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        binding.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                replaceFragments(new EditProfileFragment(), user);
            }
        });

    }

    private void replaceFragments(Fragment fragment, User model) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("data", model);
        fragment.setArguments(bundle);
        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.addToBackStack(null);
        transaction.replace(R.id.container, fragment);
        transaction.commit();
    }

}