package com.dev.doctorfinder.model;

public class HelperClass {
    public static boolean isAdmin = false;
    public static String adminID = "c9T5Dtf0wXOjNLZveUqOGD5kzYS2";
}
