package com.dev.doctorfinder.user.fragments;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.dev.doctorfinder.R;
import com.dev.doctorfinder.admin.AdminMainActivity;
import com.dev.doctorfinder.admin.fragments.AddDoctorFragment;
import com.dev.doctorfinder.admin.fragments.AdminHomeFragment;
import com.dev.doctorfinder.databinding.FragmentDoctorDetailsBinding;
import com.dev.doctorfinder.model.DoctorsModel;
import com.dev.doctorfinder.user.MainActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class DoctorDetailsFragment extends Fragment {
    FragmentDoctorDetailsBinding binding;
    DoctorsModel model;
    String checkValue = "";
    FirebaseDatabase firebaseDatabase;
    DatabaseReference reference;
    MainActivity activityUser;
    AdminMainActivity activityAdmin;
    String adminID = "c9T5Dtf0wXOjNLZveUqOGD5kzYS2";
    ProgressDialog progressDialog;
    DatabaseReference refDetails;
    String name, details,date, stars, email, location, image, productID, experts;

    public DoctorDetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            model = (DoctorsModel) getArguments().getSerializable("data");
            checkValue = getArguments().getString("value");
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if (FirebaseAuth.getInstance().getCurrentUser().getUid().contentEquals(adminID)) {
            activityAdmin = (AdminMainActivity) requireActivity();
        }else{
            activityUser = (MainActivity) requireActivity();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentDoctorDetailsBinding.inflate(inflater, container, false);
        progressDialog = new ProgressDialog(requireContext());
        progressDialog.setMessage("Loading..");
        progressDialog.setCancelable(false);
        refDetails = FirebaseDatabase.getInstance("https://doctorfinder-371dd-default-rtdb.firebaseio.com").getReference();
        return binding.getRoot();
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        if (FirebaseAuth.getInstance().getCurrentUser().getUid().contentEquals(adminID)){
            activityAdmin.binding.toolbar.tvTitle.setText("Doctor Details");
            activityAdmin.binding.toolbar.actionMenu.setImageResource(R.drawable.ic_baseline_arrow_back_ios_new_24);
            activityAdmin.binding.toolbar.actionMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    requireActivity().onBackPressed();
                }
            });
        }else{

            activityUser.binding.toolbar.tvTitle.setText("Doctor Details");
            activityUser.binding.toolbar.actionMenu.setImageResource(R.drawable.ic_baseline_arrow_back_ios_new_24);
            activityUser.binding.toolbar.actionMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    requireActivity().onBackPressed();
                }
            });
        }

        firebaseDatabase = FirebaseDatabase.getInstance("https://doctorfinder-371dd-default-rtdb.firebaseio.com");
        reference = firebaseDatabase.getReference();

        if (model != null) {
            if (Objects.equals(checkValue, "admin")) {
                binding.btnAdd.setText("Update");
                binding.btnDelete.setVisibility(View.VISIBLE);
            }

            binding.btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    reference.child("doctors").child(model.getId()).removeValue();
                    requireActivity().onBackPressed();
                }
            });
        }
        binding.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Objects.equals(checkValue, "admin")) {
                    replaceFragments(new AddDoctorFragment(), model);
                } else {
                    replaceFragments(new BookAppointmentFragment(), model);
                }
            }
        });

        binding.docLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMap(model.getLocation());
            }
        });
    }

    private void replaceFragments(Fragment fragment, DoctorsModel model) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("data", model);
        fragment.setArguments(bundle);
        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.addToBackStack(null);
        transaction.replace(R.id.container, fragment);
        transaction.commit();
    }


    private void openMap(String location) {
        Uri uriLocation = Uri.parse("geo:0,0?q=" + Uri.encode(location));
        Intent intentMap = new Intent(Intent.ACTION_VIEW, uriLocation);
        intentMap.setPackage("com.google.android.apps.maps");
        startActivity(intentMap);
    }

    @Override
    public void onResume() {
        super.onResume();
        progressDialog.show();
        refDetails.child("doctors").child(model.getId()).addListenerForSingleValueEvent(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.dismiss();
                if (snapshot.exists()) {
                    name = (String) snapshot.child("name").getValue();
                    details = (String) snapshot.child("details").getValue();
                    location = (String) snapshot.child("location").getValue();
                    image = (String) snapshot.child("image").getValue();
                    productID = (String) snapshot.child("id").getValue();
                    experts = (String) snapshot.child("experts").getValue();
                    date = (String) snapshot.child("date").getValue();
                    stars = (String) snapshot.child("star").getValue();
                    email = (String) snapshot.child("email").getValue();

                    model = new DoctorsModel(productID, name, details, date, stars, image, experts, email, location);

                    binding.tvName.setText(name);
                    binding.tVDetails.setText("Details\n\n" + details);
                    binding.docLocation.setText("Location\n\n" + location);
                    binding.tvSpecialisation.setText(experts);
                    Glide.with(requireActivity()).load(image).into(binding.imgDoc);

                } else {
                    Toast.makeText(requireContext(), "No data for user", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
                Toast.makeText(requireContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}