package com.dev.doctorfinder.admin.fragments;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.dev.doctorfinder.R;
import com.dev.doctorfinder.adapter.BookingAdaptor;
import com.dev.doctorfinder.admin.AdminMainActivity;
import com.dev.doctorfinder.databinding.FragmentAdminBookingBinding;
import com.dev.doctorfinder.model.BookingModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AdminBookingFragment extends Fragment {
    FragmentAdminBookingBinding binding;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ArrayList<BookingModel> list = new ArrayList<>();
    BookingAdaptor adaptor;
    AdminMainActivity activity;

    public AdminBookingFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (AdminMainActivity) requireActivity();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentAdminBookingBinding.inflate(inflater, container, false);
        databaseReference = FirebaseDatabase.getInstance("https://doctorfinder-371dd-default-rtdb.firebaseio.com").getReference("appointments");
        activity.binding.toolbar.tvTitle.setText("Appointments");
        activity.binding.toolbar.actionMenu.setImageResource(R.drawable.ic_menu);
        activity.binding.toolbar.actionMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.binding.drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        binding.rvAppointments.setLayoutManager(new LinearLayoutManager(requireContext()));
        adaptor = new BookingAdaptor(list, this, "admin");
        binding.rvAppointments.setAdapter(adaptor);

        ProgressDialog dialog = new ProgressDialog(requireContext());
        dialog.setMessage("Loading");
        dialog.show();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    list.clear();
                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                        BookingModel model = snapshot1.getValue(BookingModel.class);
                        list.add(model);
                        adaptor.notifyItemInserted(list.size());
                    }
                } else {
                    Toast.makeText(requireContext(), "No data to show", Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(requireContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
    }

}