package com.dev.doctorfinder.admin.fragments;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.dev.doctorfinder.R;
import com.dev.doctorfinder.admin.AdminMainActivity;
import com.dev.doctorfinder.databinding.FragmentProductDetailsBinding;
import com.dev.doctorfinder.model.CartModel;
import com.dev.doctorfinder.model.ShopModel;
import com.dev.doctorfinder.model.User;
import com.dev.doctorfinder.user.MainActivity;
import com.dev.doctorfinder.user.fragments.BookingsFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class ProductDetailsFragment extends Fragment {
    FragmentProductDetailsBinding binding;
    ShopModel model;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference ref;
    DatabaseReference reference;
    FirebaseAuth firebaseAuth;
    String checkValue = "";
    MainActivity activityUser;
    AdminMainActivity activityAdmin;
    String adminID = "c9T5Dtf0wXOjNLZveUqOGD5kzYS2";
    ProgressDialog progressDialog;
    DatabaseReference refDetails;

    String title, details, imageUri, productID;
    Long price;

    public ProductDetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            model = (ShopModel) getArguments().getSerializable("data");
            checkValue = getArguments().getString("value");
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (FirebaseAuth.getInstance().getCurrentUser().getUid().contentEquals(adminID)) {
            activityAdmin = (AdminMainActivity) requireActivity();
        } else {
            activityUser = (MainActivity) requireActivity();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentProductDetailsBinding.inflate(getLayoutInflater(), container, false);
        firebaseDatabase = FirebaseDatabase.getInstance("https://doctorfinder-371dd-default-rtdb.firebaseio.com");
        reference = firebaseDatabase.getReference();
        progressDialog = new ProgressDialog(requireContext());
        progressDialog.setMessage("Loading..");
        progressDialog.setCancelable(false);
        ref = firebaseDatabase.getReference("cart");
        refDetails = FirebaseDatabase.getInstance("https://doctorfinder-371dd-default-rtdb.firebaseio.com").getReference();
        firebaseAuth = FirebaseAuth.getInstance();
        return binding.getRoot();
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        if (FirebaseAuth.getInstance().getCurrentUser().getUid().contentEquals(adminID)) {
            activityAdmin.binding.toolbar.tvTitle.setText("Details");
            activityAdmin.binding.toolbar.actionMenu.setImageResource(R.drawable.ic_baseline_arrow_back_ios_new_24);
            activityAdmin.binding.toolbar.actionMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    requireActivity().onBackPressed();
                }
            });
        } else {
            activityUser.binding.toolbar.tvTitle.setText("Details");
            activityUser.binding.toolbar.actionMenu.setImageResource(R.drawable.ic_baseline_arrow_back_ios_new_24);
            activityUser.binding.toolbar.actionMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    requireActivity().onBackPressed();
                }
            });
        }

        if (model != null) {
            if (Objects.equals(checkValue, "admin")) {
                binding.btnAddToCart.setText("Update");
                binding.btnDelete.setVisibility(View.VISIBLE);
            }
            binding.btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    reference.child("shop").child(model.getId()).removeValue();
                    requireActivity().onBackPressed();
                }
            });
        }

        binding.btnAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Objects.equals(checkValue, "admin")) {
                    replaceFragments(new AddProductFragment(), model);

                } else {
                    addToCart();
                }
            }
        });

    }

    private void addToCart() {
        String userId = firebaseAuth.getCurrentUser().getUid();
        String id = ref.push().getKey();
        ref.child(userId).orderByChild("productId").equalTo(productID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    CartModel cartModel = new CartModel(id, title, productID, userId, String.valueOf(price), 1, imageUri);
                    ref.child(userId).child(id).setValue(cartModel).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(requireContext(), "Added to Cart", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(requireContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } else {
                    Toast.makeText(requireContext(), "Product Already exists in cart", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void replaceFragments(Fragment fragment, ShopModel model) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("data", model);
        fragment.setArguments(bundle);
        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();

        transaction.addToBackStack(null);
        transaction.replace(R.id.container, fragment);
        transaction.commit();
    }

    private void moveBack(Fragment fragment) {

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.addToBackStack(null);
        transaction.replace(R.id.container, fragment);
        transaction.commit();
    }


    @Override
    public void onResume() {
        super.onResume();
        progressDialog.show();
        refDetails.child("shop").child(model.getId()).addListenerForSingleValueEvent(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.dismiss();
                if (snapshot.exists()) {
                    title = (String) snapshot.child("title").getValue();
                    details = (String) snapshot.child("details").getValue();
                    price = (Long) snapshot.child("price").getValue();
                    imageUri = (String) snapshot.child("imageUri").getValue();
                    productID = (String) snapshot.child("id").getValue();
                    binding.title.setText(title);
                    binding.details.setText(details);
                    Glide.with(requireContext()).load(imageUri).into(binding.imgProduct);
                    binding.price.setText("MR" + price);

                } else {
                    Toast.makeText(requireContext(), "No data for user", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
                Toast.makeText(requireContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}